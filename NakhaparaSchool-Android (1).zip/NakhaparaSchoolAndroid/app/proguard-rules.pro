# The site talks to the app through the "NgpsBridge" object; keep its methods.
-keepclassmembers class com.nakhapara.schoolapp.NgpsBridge {
    @android.webkit.JavascriptInterface <methods>;
}
