/*
 * Android app layer for the school site.
 * Runs at document start inside the WebView, before the site's own scripts.
 * The site file itself is not modified: everything here is added by the app only.
 * Expects window.NGPS_APP = { tv: boolean, version: string } to be defined first.
 */
(function () {
  'use strict';
  if (window.__ngpsAppInstalled) return;            // runs once even if injected twice
  window.__ngpsAppInstalled = true;

  var APP = window.NGPS_APP || { tv: false, version: 'dev' };
  var VIEW_KEY = 'ngps101_preferred_device_view';    // the site's own storage key for its view mode

  /* 1. On a TV, start in the site's "tv" view unless the user already chose a view. */
  try {
    if (APP.tv && !localStorage.getItem(VIEW_KEY)) localStorage.setItem(VIEW_KEY, 'tv');
  } catch (e) { /* storage unavailable: nothing to do */ }

  /* The page's <html> element may not exist yet when this runs at document start. */
  function setupDom() {
    var root = document.documentElement;
    root.classList.add('ngps-app');
    if (APP.tv) root.classList.add('ngps-tv');
    var style = document.createElement('style');
    style.id = 'ngps-app-style';
    style.textContent = APP_CSS();
    root.appendChild(style);
  }
  if (document.documentElement) setupDom();
  else new MutationObserver(function (_, obs) { if (document.documentElement) { obs.disconnect(); setupDom(); } })
         .observe(document, { childList: true, subtree: true });

  /* 2. Large-screen styles. The selector prefix is deliberately specific so these
        win over the site's own view rules; the web version is not affected. */
  function APP_CSS() {
  var P = 'html.ngps-app body[data-ngps-active-view]';
  var css = [
    P + ' #v28-burger{display:flex!important;position:fixed!important;top:16px!important;right:16px!important;left:auto!important;' +
      'width:84px!important;height:84px!important;font-size:40px!important;border-radius:22px!important;z-index:9600!important;' +
      'background:linear-gradient(135deg,#facc15,#eab308)!important;color:#0f172a!important;border:3px solid #fff!important;' +
      'align-items:center!important;justify-content:center!important;box-shadow:0 6px 20px rgba(0,0,0,.4)!important}',
    P + '{padding-left:0!important}',
    P + ' nav.dz-nav{display:none!important}',
    P + '.v28-open nav.dz-nav{display:flex!important;position:fixed!important;inset:0!important;width:100%!important;height:100%!important;' +
      'max-height:none!important;left:0!important;right:0!important;top:0!important;bottom:0!important;z-index:9500!important;' +
      'align-items:center!important;justify-content:center!important;padding:32px!important;box-sizing:border-box!important;' +
      'background:rgba(2,8,36,.96)!important;border:0!important;box-shadow:none!important;transform:none!important;opacity:1!important;visibility:visible!important}',
    P + '.v28-open nav.dz-nav .dz-nav-in{display:flex!important;flex-direction:column!important;gap:16px!important;' +
      'width:min(980px,100%)!important;height:auto!important;max-height:100%!important;overflow-y:auto!important;padding:0 8px 24px!important;box-sizing:border-box!important}',
    P + '.v28-open nav.dz-nav .dz-nav-in > button{width:100%!important;min-height:92px!important;font-size:34px!important;font-weight:800!important;' +
      'padding:18px 28px!important;border-radius:24px!important;text-align:left!important;justify-content:flex-start!important;line-height:1.25!important}',
    P + ' main.dz-main{margin-left:0!important;max-width:100%!important;width:100%!important;padding:16px 20px 48px!important;box-sizing:border-box!important}',
    P + ' header.dz-top .dz-top-in{padding-right:120px!important}',
    /* quick-action column moves to the right edge so it does not cover the section */
    'html.ngps-app .nkx-dock,html.ngps-app #ngps51Fab{left:auto!important;right:12px!important;bottom:110px!important}',
    /* while the menu is open, the floating dock and bottom bars step aside */
    'html.ngps-app body.v28-open .nkx-dock,html.ngps-app body.v28-open #ngps51Fab,html.ngps-app body.v28-open #ngps76BottomNav,html.ngps-app body.v28-open #ngps101TabDock{display:none!important}',
    'html.ngps-tv :focus{outline:6px solid #facc15!important;outline-offset:5px!important;box-shadow:0 0 0 12px rgba(250,204,21,.28)!important}',
    'html.ngps-tv button,html.ngps-tv a,html.ngps-tv input,html.ngps-tv select,html.ngps-tv textarea{min-height:64px}',
    'html.ngps-tv #ngps101DeviceBar{display:none!important}',
    '@media (max-width:767px){' +
      P + ' #v28-burger{width:64px!important;height:64px!important;font-size:30px!important;top:10px!important;right:10px!important}' +
      P + '.v28-open nav.dz-nav .dz-nav-in > button{font-size:24px!important;min-height:72px!important;padding:14px 18px!important}}'
  ];
  return css.join('\n');
  }

  /* 3. Menu helpers used by the Android back button. */
  function menuOpen() { return !!document.body && document.body.classList.contains('v28-open'); }
  function closeMenu() { if (document.body) document.body.classList.remove('v28-open'); }

  // Called by the app on Back. Returns true when it handled the key.
  window.__ngpsBack = function () {
    if (menuOpen()) { closeMenu(); return true; }
    var active = document.querySelector('.tab-btn.dz-active');
    if (active && active.getAttribute('data-tab') && active.getAttribute('data-tab') !== 'dashboard' &&
        typeof window.switchTab === 'function') {
      window.switchTab('dashboard');
      return true;
    }
    return false;
  };

  /* 4. Remote-control (D-pad) navigation: arrows move focus to the nearest control in that direction. */
  var FOCUSABLE = 'button, a[href], input, select, textarea, [role="button"], [tabindex]:not([tabindex="-1"])';

  function visibleFocusables() {
    var scope = menuOpen() ? (document.querySelector('nav.dz-nav') || document) : document;
    return Array.prototype.filter.call(scope.querySelectorAll(FOCUSABLE), function (el) {
      if (el.disabled) return false;
      var cs = getComputedStyle(el);
      if (cs.display === 'none' || cs.visibility === 'hidden') return false;
      var r = el.getBoundingClientRect();
      return r.width > 4 && r.height > 4 && r.bottom > 0 && r.right > 0 &&
             r.top < window.innerHeight && r.left < window.innerWidth;
    });
  }

  function nearest(dir, cur, list) {
    var cr = cur.getBoundingClientRect();
    var cx = cr.left + cr.width / 2, cy = cr.top + cr.height / 2;
    var vertical = dir === 'ArrowDown' || dir === 'ArrowUp';
    var best = null, bestScore = Infinity;
    for (var i = 0; i < list.length; i++) {
      var el = list[i];
      if (el === cur) continue;
      var r = el.getBoundingClientRect();
      var dx = r.left + r.width / 2 - cx, dy = r.top + r.height / 2 - cy;
      var inDir = dir === 'ArrowDown' ? dy > 4 : dir === 'ArrowUp' ? dy < -4 : dir === 'ArrowRight' ? dx > 4 : dx < -4;
      if (!inDir) continue;
      var main = vertical ? Math.abs(dy) : Math.abs(dx);
      var side = vertical ? Math.abs(dx) : Math.abs(dy);
      var score = main + side * 2.5;               // prefer targets straight ahead
      if (score < bestScore) { bestScore = score; best = el; }
    }
    return best;
  }

  window.addEventListener('keydown', function (e) {
    if (!APP.tv) return;
    var dirs = ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'];
    if (dirs.indexOf(e.key) === -1) return;
    var list = visibleFocusables();
    if (!list.length) return;
    var cur = document.activeElement;
    if (list.indexOf(cur) === -1) { list[0].focus({ preventScroll: true }); e.preventDefault(); return; }
    var next = nearest(e.key, cur, list);
    if (next) {
      e.preventDefault();
      next.focus({ preventScroll: true });
      next.scrollIntoView({ block: 'center', inline: 'nearest', behavior: 'smooth' });
    }
  }, true);

  /* 5. Downloads: the site saves files through blob: links; hand them to the app to store. */
  window.addEventListener('click', function (e) {
    var a = e.target && e.target.closest ? e.target.closest('a[download]') : null;
    if (!a || !window.NgpsBridge || typeof NgpsBridge.saveFile !== 'function') return;
    var href = a.getAttribute('href') || '';
    if (href.indexOf('blob:') !== 0 && href.indexOf('data:') !== 0) return;
    e.preventDefault(); e.stopPropagation();
    var name = a.getAttribute('download') || 'download';
    fetch(href).then(function (r) { return r.blob(); }).then(function (blob) {
      var fr = new FileReader();
      fr.onload = function () {
        var b64 = String(fr.result).split(',')[1] || '';
        NgpsBridge.saveFile(name, blob.type || 'application/octet-stream', b64);
      };
      fr.readAsDataURL(blob);
    }).catch(function () {
      if (window.NgpsBridge && typeof NgpsBridge.toast === 'function') NgpsBridge.toast('ফাইল সংরক্ষণ করা যায়নি');
    });
  }, true);

  /* 6. window.print() opens the native print dialog (a WebView would otherwise do nothing). */
  window.print = function () {
    if (window.NgpsBridge && typeof NgpsBridge.printPage === 'function') NgpsBridge.printPage();
  };
})();
