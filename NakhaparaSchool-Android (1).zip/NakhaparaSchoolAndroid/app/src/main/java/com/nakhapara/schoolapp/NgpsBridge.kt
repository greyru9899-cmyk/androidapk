package com.nakhapara.schoolapp

import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * Methods the site (through the app-start.js layer) can call on the native side:
 *   NgpsBridge.saveFile(name, mime, base64)  -> save a downloaded file
 *   NgpsBridge.printPage()                   -> open the print dialog
 *   NgpsBridge.toast(message)                -> short message on screen
 *   NgpsBridge.isTv()                        -> true on Google TV / Android TV
 *
 * JavascriptInterface methods run on a background thread; UI work is posted back.
 */
class NgpsBridge(private val activity: MainActivity, private val owner: WebView) {

    @JavascriptInterface
    fun saveFile(name: String, mime: String, base64: String): Boolean =
        activity.saveBase64(name, mime, base64)

    @JavascriptInterface
    fun printPage() {
        activity.runOnUiThread { activity.printWebView(owner) }
    }

    @JavascriptInterface
    fun toast(message: String) {
        activity.toast(message)
    }

    @JavascriptInterface
    fun isTv(): Boolean = activity.isTelevision()
}
