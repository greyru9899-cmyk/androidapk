package com.nakhapara.schoolapp

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.app.UiModeManager
import android.content.ActivityNotFoundException
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Message
import android.print.PrintAttributes
import android.print.PrintManager
import android.provider.MediaStore
import android.util.Log
import android.webkit.DownloadListener
import android.webkit.PermissionRequest
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/**
 * Shows the school site (bundled in assets/site/index.html) full screen in a WebView.
 * The site is served from https://appassets.androidplatform.net, a secure origin, so that
 * localStorage, Firebase sign-in and other web features behave as they do on the web.
 */
class MainActivity : AppCompatActivity() {

    companion object {
        private const val TAG = "NakhaparaSchool"
        private const val HOST = "appassets.androidplatform.net"
        private const val APP_ORIGIN = "https://$HOST"
        private const val HOME_URL = "$APP_ORIGIN/assets/site/index.html"
    }

    private lateinit var root: FrameLayout
    private lateinit var mainWeb: WebView
    private lateinit var assetLoader: WebViewAssetLoader
    private lateinit var startScript: String

    private val popups = mutableListOf<WebView>()
    private var filePathCallback: ValueCallback<Array<Uri>>? = null
    private var pendingPermission: PermissionRequest? = null
    private var isTv = false

    private val fileChooser = registerForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        filePathCallback?.onReceiveValue(if (uris.isEmpty()) null else uris.toTypedArray())
        filePathCallback = null
    }

    private val mediaPermission = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        pendingPermission?.let { answer(it) }
        pendingPermission = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        root = findViewById(R.id.root)
        mainWeb = findViewById(R.id.webview)
        isTv = isTelevision()

        assetLoader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()
        startScript = buildStartScript()

        configure(mainWeb, popup = false)
        if (savedInstanceState != null) {
            mainWeb.restoreState(savedInstanceState)
        } else {
            mainWeb.loadUrl(HOME_URL)
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() = handleBack()
        })
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        mainWeb.saveState(outState)
    }

    override fun onDestroy() {
        popups.toList().forEach { closePopup(it) }
        mainWeb.destroy()
        super.onDestroy()
    }

    // ----- WebView setup -------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun configure(wv: WebView, popup: Boolean) {
        wv.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            useWideViewPort = true
            loadWithOverviewMode = true
            javaScriptCanOpenWindowsAutomatically = true
            setSupportMultipleWindows(true)
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            cacheMode = WebSettings.LOAD_DEFAULT
            // Bigger text on a TV, which is viewed from across the room.
            textZoom = if (isTv) 135 else 110
        }
        wv.isFocusable = true
        wv.isFocusableInTouchMode = true
        wv.addJavascriptInterface(NgpsBridge(this, wv), "NgpsBridge")
        wv.webViewClient = AppWebViewClient(popup)
        wv.webChromeClient = AppChromeClient()
        wv.setDownloadListener(AppDownloadListener())

        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            WebViewCompat.addDocumentStartJavaScript(wv, startScript, setOf(APP_ORIGIN))
        }
        WebView.setWebContentsDebuggingEnabled(
            (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0
        )
    }

    private fun createWebView(popup: Boolean): WebView {
        val wv = WebView(this)
        configure(wv, popup)
        return wv
    }

    private fun buildStartScript(): String {
        val js = assets.open("app/app-start.js").bufferedReader(Charsets.UTF_8).use { it.readText() }
        return "window.NGPS_APP = { tv: $isTv, version: '1.0.0' };\n$js"
    }

    // ----- Clients ---------------------------------------------------------------------------

    private inner class AppWebViewClient(private val popup: Boolean) : WebViewClient() {

        override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
            assetLoader.shouldInterceptRequest(request.url)

        override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
            val uri = request.url
            val external = when (uri.scheme) {
                "http", "https" -> uri.host != HOST
                "mailto", "tel", "sms", "whatsapp", "intent" -> true
                else -> false
            }
            if (!external) return false
            openExternal(uri)
            // a popup that only existed to open a link is no longer needed (close it after this callback returns)
            if (popup) view.post { closePopup(view) }
            return true
        }

        override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
            // Fallback for WebViews where the start script could not be registered in advance.
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                view.evaluateJavascript(startScript, null)
            }
        }
    }

    private inner class AppChromeClient : WebChromeClient() {

        override fun onShowFileChooser(
            webView: WebView,
            callback: ValueCallback<Array<Uri>>,
            params: WebChromeClient.FileChooserParams
        ): Boolean {
            filePathCallback?.onReceiveValue(null)
            filePathCallback = callback
            val accept = params.acceptTypes?.filter { it.isNotBlank() } ?: emptyList()
            val mime = if (accept.isNotEmpty() && accept.all { it.startsWith("image") }) "image/*" else "*/*"
            return try {
                fileChooser.launch(mime)
                true
            } catch (e: ActivityNotFoundException) {
                filePathCallback = null
                false
            }
        }

        override fun onPermissionRequest(request: PermissionRequest) {
            runOnUiThread {
                val needed = mutableListOf<String>()
                if (PermissionRequest.RESOURCE_AUDIO_CAPTURE in request.resources &&
                    !hasPermission(Manifest.permission.RECORD_AUDIO)) needed += Manifest.permission.RECORD_AUDIO
                if (PermissionRequest.RESOURCE_VIDEO_CAPTURE in request.resources &&
                    !hasPermission(Manifest.permission.CAMERA)) needed += Manifest.permission.CAMERA

                if (needed.isEmpty()) {
                    answer(request)
                } else {
                    pendingPermission = request
                    mediaPermission.launch(needed.toTypedArray())
                }
            }
        }

        override fun onCreateWindow(view: WebView, isDialog: Boolean, isUserGesture: Boolean, resultMsg: Message): Boolean {
            // The site opens print previews and some links in a new window; show it as a layer on top.
            val child = createWebView(popup = true)
            (resultMsg.obj as WebView.WebViewTransport).webView = child
            resultMsg.sendToTarget()
            root.addView(child, FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT))
            popups.add(child)
            child.requestFocus()
            return true
        }

        override fun onCloseWindow(window: WebView) {
            root.post { closePopup(window) }
        }
    }

    private inner class AppDownloadListener : DownloadListener {
        override fun onDownloadStart(
            url: String,
            userAgent: String?,
            contentDisposition: String?,
            mimeType: String?,
            contentLength: Long
        ) {
            try {
                val name = URLUtil.guessFileName(url, contentDisposition, mimeType)
                val request = DownloadManager.Request(Uri.parse(url))
                    .setMimeType(mimeType)
                    .setTitle(name)
                    .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                    .setDestinationInExternalFilesDir(this@MainActivity, Environment.DIRECTORY_DOWNLOADS, name)
                (getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager).enqueue(request)
                toast("ডাউনলোড শুরু হয়েছে: $name")
            } catch (e: Exception) {
                Log.w(TAG, "download failed", e)
                toast("ডাউনলোড শুরু করা যায়নি")
            }
        }
    }

    // ----- Back button -----------------------------------------------------------------------

    private fun handleBack() {
        val top = popups.lastOrNull()
        if (top != null) {
            closePopup(top)
            return
        }
        // The page decides first: it closes the menu, or returns to the dashboard.
        mainWeb.evaluateJavascript(
            "(function(){ try { return !!(window.__ngpsBack && window.__ngpsBack()); } catch (e) { return false; } })()"
        ) { result ->
            if (result == "true") return@evaluateJavascript
            if (mainWeb.canGoBack()) mainWeb.goBack() else finish()
        }
    }

    private fun closePopup(wv: WebView) {
        if (popups.remove(wv)) {
            root.removeView(wv)
            wv.stopLoading()
            wv.destroy()
        }
    }

    // ----- Helpers used by NgpsBridge and the clients ----------------------------------------

    internal fun isTelevision(): Boolean {
        val uiMode = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return uiMode.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            packageManager.hasSystemFeature(PackageManager.FEATURE_TELEVISION) ||
            packageManager.hasSystemFeature("android.software.leanback")
    }

    internal fun toast(message: String) {
        runOnUiThread { Toast.makeText(this, message, Toast.LENGTH_SHORT).show() }
    }

    /** Saves a file produced by the site (base64 data) into the Downloads folder. */
    internal fun saveBase64(name: String, mime: String, base64: String): Boolean {
        return try {
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            val safeName = name.replace(Regex("[\\\\/:*?\"<>|]"), "_").ifBlank { "download" }
            val type = mime.ifBlank { "application/octet-stream" }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                val values = ContentValues().apply {
                    put(MediaStore.Downloads.DISPLAY_NAME, safeName)
                    put(MediaStore.Downloads.MIME_TYPE, type)
                    put(MediaStore.Downloads.IS_PENDING, 1)
                }
                val uri = contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values) ?: return false
                val out = contentResolver.openOutputStream(uri) ?: return false
                out.use { it.write(bytes) }
                values.clear()
                values.put(MediaStore.Downloads.IS_PENDING, 0)
                contentResolver.update(uri, values, null, null)
            } else {
                val dir = getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: filesDir
                File(dir, safeName).writeBytes(bytes)
            }
            toast("ফাইল সংরক্ষণ হয়েছে: $safeName")
            true
        } catch (e: Exception) {
            Log.e(TAG, "save failed", e)
            toast("ফাইল সংরক্ষণ করা যায়নি")
            false
        }
    }

    /** Opens the system print dialog for the page in [wv]. */
    internal fun printWebView(wv: WebView) {
        val printManager = getSystemService(Context.PRINT_SERVICE) as PrintManager
        val title = getString(R.string.app_name)
        printManager.print(title, wv.createPrintDocumentAdapter(title), PrintAttributes.Builder().build())
    }

    private fun hasPermission(permission: String): Boolean =
        ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED

    private fun answer(request: PermissionRequest) {
        val allowed = request.resources.filter { resource ->
            when (resource) {
                PermissionRequest.RESOURCE_AUDIO_CAPTURE -> hasPermission(Manifest.permission.RECORD_AUDIO)
                PermissionRequest.RESOURCE_VIDEO_CAPTURE -> hasPermission(Manifest.permission.CAMERA)
                else -> false
            }
        }.toTypedArray()
        if (allowed.isEmpty()) request.deny() else request.grant(allowed)
    }

    private fun openExternal(uri: Uri) {
        try {
            val intent = if (uri.scheme == "intent") {
                Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, uri)
            }
            startActivity(intent)
        } catch (e: Exception) {
            Log.w(TAG, "cannot open $uri", e)
            toast("এই লিংকটি খোলা যায়নি")
        }
    }
}
